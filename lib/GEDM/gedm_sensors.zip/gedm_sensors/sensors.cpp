/*
#  ██████        ███████ ██████  ███    ███  
# ██             ██      ██   ██ ████  ████  
# ██   ███ █████ █████   ██   ██ ██ ████ ██ 
# ██    ██       ██      ██   ██ ██  ██  ██ 
#  ██████        ███████ ██████  ██      ██ 
#
# This is a beta version for testing purposes.
# Only for personal use. Commercial use or redistribution without permission is prohibited. 
# Copyright (c) Roland Lautensack    
*/ 
#include "sensors.h"
#include "gedm_api/api.h"
#include "tft_display/ili9341_tft.h"
//#include "gedm_adc_external/gedm_adc_driver.h"
#include "gedm_dpm_driver/gedm_dpm_driver.h"

//TaskHandle_t vsense_tasks[num_vsense_tasks];
TaskHandle_t main_sensor_task;
hw_timer_t * vsense_adc_sampler_timer = NULL; 

DMA_ATTR volatile int      bailed_samples        = 0;
DMA_ATTR volatile int      vsense_is_reading     = 0;
DMA_ATTR volatile int      last_adc_in_use       = 0;
DMA_ATTR volatile unsigned long bench_timer      = millis();
DMA_ATTR volatile int      bench_count           = 0;
DMA_ATTR volatile bool     block_core_0_access   = false;
DMA_ATTR volatile int      reference_adc_value   = 0;
DMA_ATTR volatile uint32_t feedback_voltage      = 0.0;
DMA_ATTR volatile float    source_voltage        = 0.0;
DMA_ATTR volatile int      vsense_update_counter = 0;
DMA_ATTR volatile int      motion_plan           = 0;
DMA_ATTR volatile int      motion_plan_previous  = 0;

DMA_ATTR volatile int      counter[7]            = {0,0,0,0,0,0,0};
DMA_ATTR volatile int      vsense_multisample_counts;
DMA_ATTR volatile uint32_t vsense_multisample_buffer[vsense_sampler_buffer_size];
DMA_ATTR volatile int      on_off_switch_event_detected = true;
DMA_ATTR volatile int      adc_isr_reading[3]       = {0,0,0};
DMA_ATTR volatile int      adc_isr_reading_shunt[3] = {0,0,0};

DMA_ATTR volatile int      adc_setpoints[4]   = {0,0,0,0};

bool is_ready = false;

static esp_adc_cal_characteristics_t adc1_chars;

G_EDM_SENSORS::G_EDM_SENSORS(){
}

void G_EDM_SENSORS::init_adc(){
    is_ready = true;
    if( USE_EXTERNAL_SPI_ADC ){ 
        //AD4000_adc.set_spi_instance( tft.getSPIinstance() );
        //AD4000_adc.begin( EXTERNAL_SPI_ADC_CS_PIN, EXTERNAL_SPI_ADC_FREQUENCY );
    } else if( USE_DPM_RXTX_SERIAL_COMMUNICATION ){
        dpm_driver.setup( Serial );
        dpm_driver.init();
    }
    //vsense_tasks_init();

    xTaskCreatePinnedToCore(default_sensor_task, "sensor_task", 1000, this, 4, &main_sensor_task, 0);
}

void G_EDM_SENSORS::run_sensor_service(){
    adc1_config_width(ADC_WIDTH_12Bit);
    adc1_config_channel_atten( ADC1_CHANNEL_6, ADC_ATTEN_11db );
    adc1_get_raw( ADC1_CHANNEL_6 ); 
    esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_11db, ADC_WIDTH_BIT_12, 0, &adc1_chars);
    pinMode(ON_OFF_SWITCH_PIN, INPUT);
    pinMode(VSENSE_FEEDBACK_PIN, INPUT);
    attachInterrupt(ON_OFF_SWITCH_PIN, switch_on_interrupt, CHANGE);
}
bool G_EDM_SENSORS::is_probing(){
    return sys_probe_state == Probe::Active ? true : false;
}
bool G_EDM_SENSORS::continue_edm_process(){
  return stop_edm_task? false : true;
}
bool G_EDM_SENSORS::start_edm_process(){
  if( 
    sys_rt_exec_alarm != ExecAlarm::None 
    || sys.gedm_stop_process 
    || sys_rt_exec_state.bit.motionCancel
){
    return false;
  } return start_edm_task;
}
uint32_t IRAM_ATTR G_EDM_SENSORS::adc1_get_fast(int channel) {
    //if( USE_EXTERNAL_SPI_ADC ){ return AD4000_adc.read(); }
    SENS.sar_meas_start1.sar1_en_pad = (1 << channel);
    while (SENS.sar_slave_addr1.meas_status != 0);
    SENS.sar_meas_start1.meas1_start_sar = 0;
    SENS.sar_meas_start1.meas1_start_sar = 1;
    while (SENS.sar_meas_start1.meas1_done_sar == 0);
    return SENS.sar_meas_start1.meas1_data_sar;
}
void IRAM_ATTR read_shunt(){
    uint32_t sample = analogRead(35);//G_EDM_SENSORS::adc1_get_fast(ADC1_CHANNEL_7);
    int c = 0;
    int a=10;
    for( int i = 0; i < a; ++i ){
        c += G_EDM_SENSORS::adc1_get_fast(ADC1_CHANNEL_7);//analogRead(35);
    }
    c/=a;
    sample=c;
    adc_isr_reading_shunt[0] = sample;
    adc_isr_reading_shunt[1] = int( ( sample + adc_isr_reading_shunt[1] ) / 2 );
    adc_isr_reading_shunt[2] = esp_timer_get_time();
    // milliamps
    int milliamps = ((SHUNT_OPAMP_MAX_AMP*1000)/SHUNT_OPAMP_ADC_AT_MAX_AMP)*adc_isr_reading_shunt[1];  
    milliamps /= 1000;
    Serial.println( String( milliamps ) + "mA   ADC:" + String( sample ) );
}



void IRAM_ATTR vsense_on_timer() {
    if( block_core_0_access ){
        return;
    }
    read_vsense();
    return;
}

void IRAM_ATTR default_sensor_task(void *parameter)
{
    bool timer_is_at_high_speed = false; // initial speed is low speed
    vsense_adc_sampler_timer = timerBegin(3, 80, true);
    timerAttachInterrupt(vsense_adc_sampler_timer, &vsense_on_timer, true);
    timerAlarmWrite(vsense_adc_sampler_timer, VSENSE_FEEDBACK_TIMER_INTERVAL_DEFAULT, true);
    timerAlarmEnable(vsense_adc_sampler_timer);
    for (;;)
    {
        //Serial.println(int( uxTaskGetStackHighWaterMark(NULL) ));
        //Serial.println(ESP.getFreeHeap());
        if (
            !G_EDM_SENSORS::is_probing() && (!edm_process_is_running || sys.edm_pause_motion || !sys.gedm_planner_line_running))
        {
            if (timer_is_at_high_speed)
            {
                timerAlarmWrite(vsense_adc_sampler_timer, VSENSE_FEEDBACK_TIMER_INTERVAL_DEFAULT, true);
                timer_is_at_high_speed = false;
            }
        }
        else
        {
            if (!timer_is_at_high_speed)
            {
                timerAlarmWrite(vsense_adc_sampler_timer, VSENSE_FEEDBACK_TIMER_INTERVAL_EDM, true);
                timer_is_at_high_speed = true;
            }
        }

        /** Monitor On/Off Switch change events **/
        if( on_off_switch_event_detected ){
            G_EDM_SENSORS::edm_start_stop();
        }

        vTaskDelay(300);

    }
    vTaskDelete(NULL);
}



int IRAM_ATTR G_EDM_SENSORS::get_number_of_samples(){
    int num_samples = MULTISAMPLING_DEFAULT; // determine the number of samples we want for this call
    if( G_EDM_SENSORS::is_probing() ){
        num_samples = MULTISAMPLING_PROBING;
    } else if( sys.gedm_retraction_motion ){
        num_samples = MULTISAMPLING_RETRACTION;
    }
    return num_samples;
}

uint32_t G_EDM_SENSORS::get_feedback_voltage( int adc_value )
{
    if( ! adc_value ){adc_value = adc_isr_reading[0];}
    feedback_voltage = adc_to_voltage( adc_value );
    return feedback_voltage;
}
uint32_t IRAM_ATTR G_EDM_SENSORS::adc_to_voltage( int adc_value ){
    if( adc_value <= 0 ){ return 0; }
    if( USE_EXTERNAL_SPI_ADC ){
        return round(EXTERNAL_SPI_ADC_REF_VOLTAGE*1000/EXTERNAL_SPI_ADC_RESOLUTION*adc_value/1000);
    }
    return round(VSENSE_MAX*1000/VSENSE_RESOLUTION*adc_value/1000);
    //return esp_adc_cal_raw_to_voltage(adc_value, &adc1_chars); // not so good.. Offsets the 0v input to 142mV and may need calibration.
}

void IRAM_ATTR G_EDM_SENSORS::generate_setpoint_min_max_adc( int adc_reading_reference ){

    if( adc_reading_reference <= 0 ){
        adc_reading_reference = reference_adc_value;
    }

    float short_circuit_setpoint = vsense_drop_range_max+15.0;
    if( short_circuit_setpoint > VSENSE_DROP_RANGE_SHORT ){
        short_circuit_setpoint = VSENSE_DROP_RANGE_SHORT;
    }

    if( VSENSE_INVERTED ){
        // voltage starts at 0v and goes up with more load
        float resolution = float( USE_EXTERNAL_SPI_ADC ? EXTERNAL_SPI_ADC_RESOLUTION : VSENSE_RESOLUTION ) / 100.0;
        adc_setpoints[0] = round( resolution * vsense_drop_range_min );
        adc_setpoints[1] = round( resolution * vsense_drop_range_max );
        adc_setpoints[2] = round( resolution * short_circuit_setpoint );
        adc_setpoints[3] = round( resolution * vSense_drop_range_noload );
        return;
    }

    float resolution = float( adc_reading_reference ) / 100.0;
    // generate the adc value for the lower setpoint
    adc_setpoints[0] = adc_reading_reference - round( resolution * vsense_drop_range_min );
    // generate the adc value for the upper setpoint
    adc_setpoints[1] = adc_reading_reference - round( resolution * vsense_drop_range_max );
    // generate the adc value for the short setpoint // warning: This is a high value and depending on the pulsegen settings may not be reached in the process!
    adc_setpoints[2] = adc_reading_reference - round( resolution * short_circuit_setpoint );
    // generate the adc setpoint for probing
    adc_setpoints[3] = adc_reading_reference - round( resolution * vSense_drop_range_noload );
    //Serial.println("Setpoint ADC min: "+String(adc_setpoints[0] ));
    //Serial.println("Setpoint ADC max: "+String(adc_setpoints[1] ));
}























void IRAM_ATTR G_EDM_SENSORS::reset_buffer( int exclude ){
    for(int i=0;i<7;++i){if( i != exclude ){counter[i] = 0;}}
}
int IRAM_ATTR G_EDM_SENSORS::get_motion_plan_probing(int adc_value_realtime, int adc_value_multisampled)
{
    int plan_in_use = 2; // in probing 0=move, 1=hold, 3= probe touched
    if (probe_touched)
    {
        counter[5] = 0; // reset probe counter
        vTaskDelay(1);
        return 4;
    }

    if (
           (!VSENSE_INVERTED && adc_value_multisampled < adc_setpoints[3]) 
        || ( VSENSE_INVERTED && adc_value_multisampled > adc_setpoints[3]))
    {
        // maybe a contact
        // set the plan to hold
        plan_in_use = 2; // pause motion
        if (++counter[5] > MOTION_PLAN_PROBE_CONFIRMATIONS)
        {
            plan_in_use = 4; // probe confirmed
            probe_touched = true;
        }
    }
    else
    {
        probe_touched = false;
        if (
            counter[5] > 0 
            //|| !pwm_pulse_high 
            || (!VSENSE_INVERTED && last_adc_in_use - adc_value_realtime > 100) 
            || ( VSENSE_INVERTED && adc_value_realtime - last_adc_in_use > 100))
        {
            plan_in_use = 2; // skip one round after a positive
        }
        else
        {
            plan_in_use = 1;
        }
        counter[5] = 0; // fully reset the counter
    }
    last_adc_in_use = adc_value_realtime;
    return plan_in_use;
}





void G_EDM_SENSORS::generate_reference_voltage(){
    block_core_0_access = true;
    int adc_collector = 0;
    int adc_collected = 0;
    vTaskDelay(10);
    ui_controller.pwm_off();
    vTaskDelay(10);
    ui_controller.pwm_on(); // just in case
    vTaskDelay(10);
    for( int i = 0; i < 100; ++i ){
        int adc_value = analogRead( VSENSE_FEEDBACK_PIN );
        adc_collector += adc_value;//adc1_get_fast( ADC1_CHANNEL_6 );
        ++adc_collected;
        vTaskDelay(5);
    }
    reference_adc_value = int(adc_collector/adc_collected);
    generate_setpoint_min_max_adc( reference_adc_value );
    block_core_0_access = false;
}


IRAM_ATTR bool G_EDM_SENSORS::edm_start_stop()
{
    vTaskDelay(DEBOUNCE_PERIOD / portTICK_PERIOD_MS); 
    bool state  = false;
    if (digitalRead(ON_OFF_SWITCH_PIN))
    {
        stop_edm_task = 0;
        if (!edm_process_is_running)
        {
            start_edm_task = 1;
        }
        if (sys_rt_exec_state.bit.motionCancel)
        {
            force_redraw = true;
        }
        sys_rt_exec_state.bit.motionCancel = false;
        state = true;
    }
    else
    {
        start_edm_task = 0;
        if (edm_process_is_running)
        {
            stop_edm_task = 1;
        }
        if (!sys_rt_exec_state.bit.motionCancel)
        {
            force_redraw = true;
        }
        sys_rt_exec_state.bit.motionCancel = true;
        state = false;
    }
    on_off_switch_event_detected = false;
    return state;
}
void IRAM_ATTR switch_on_interrupt(){
    if( !on_off_switch_event_detected ){
        on_off_switch_event_detected = true;
    }
}












bool IRAM_ATTR G_EDM_SENSORS::vsense_is_outdated(){
    return ( uint64_t ) esp_timer_get_time() - ( uint64_t ) adc_isr_reading[2] > MAX_ADC_READING_AGE ? true : false;
}








/** 
  * returns 
  * 1 = drop is below setpoint -> move
  * 2 = drop is within setpoint range at bottom end ( closer to noload than short circuit ) 
  * 3 = drop is within setpoint range at upper end ( closer to short circuit than noload )
  * 4 = drop is above setpoint 
  * 5 = for sure shorted (not used)
  * This raw plan does not validate the feedback
  * it returns the plan without caring about noise
  **/
int G_EDM_SENSORS::get_raw_plan( int adc_value ){
    int plan = 2;
    if( VSENSE_INVERTED ){
        if( adc_value < adc_setpoints[0] ){
            plan = 1; // below setpoint
        } else if( adc_value > adc_setpoints[1] ){
            if( adc_value > adc_setpoints[2] ){
                plan = 5; // 100% short
            } else {
                plan = 4; // above setpoint
            }
        } else if( adc_value > ( adc_setpoints[0] + adc_setpoints[1] ) / 2 ){
            plan = 3; // upper setpoint
        } else {
            plan = 2; // lower setpoint
        }
    } else {
        if( adc_value > adc_setpoints[0] ){
            plan = 1; // below setpoint
        } else if( adc_value < adc_setpoints[1] ){
            if( adc_value < adc_setpoints[2] ){
                plan = 5; // 100% short
            } else {
                plan = 4; // above setpoint
            }
        } else if( adc_value < ( adc_setpoints[0] + adc_setpoints[1] ) / 2 ){
            plan = 3; // upper setpoint
        } else {
            plan = 2; // lower setpoint
        }
    }
    return plan;
}




int64_t timestamp_last_above_setpoint = 0;
int G_EDM_SENSORS::get_motion_plan(int adc_value_realtime, int adc_value_multisampled, bool retract_motion, bool peek)
{

    int realtime_plan  = get_raw_plan(adc_value_realtime);
    int sampled_plan   = get_raw_plan(adc_value_multisampled);
    //int vsense_is_high = (GPIO_REG_READ(GPIO_IN1_REG) >> (gpio_num_t)(VSENSE_FEEDBACK_PIN & 0x1F)) & 1U;
    //if (VSENSE_INVERTED){ vsense_is_high = !vsense_is_high; }
    bool reset_counter = true;
    int plan_in_use    = sampled_plan;
    if ( retract_motion ){

        if ( realtime_plan <= SHORT_CANCELED_AT_MOTION_PLAN ){ // short canceled
            plan_in_use = realtime_plan;
            counter[1] = 0; 
        }

    } else {




        /*if ( plan_in_use == 1 && ++counter[plan_in_use] < FORWARD_CONFIRMATIONS ){
            ++plan_in_use;
            reset_counter = false;
        } 
        if( plan_in_use == 2 && counter[2] > 50 ){
            counter[2] = 0;
            reset_counter = false;
            ++plan_in_use; // validate this. May it is NOT better to force a forward move... // force a forward move. It is better to create a short than retract here. Electrode would just move back in the idle position after a retraction-
        } else if( plan_in_use == 1 && counter[1] > 50 ){
            ++plan_in_use;
        }*/

    }

    ++counter[plan_in_use];
    if (reset_counter){
        reset_buffer(plan_in_use);
    }

    return plan_in_use;
}


int IRAM_ATTR G_EDM_SENSORS::get_calculated_motion_plan(){

    block_core_0_access = true;
    while(vsense_is_reading){ if( sys.abort || sys_rt_exec_state.bit.motionCancel ){ break; } }
    int count              = 0;
    int peek_motion_plan   = 0;
    int samples            = 1;
    int short_counter      = 0;
    int plan               = 0;
    bool wait_for_high_pwm = false;


    if( is_probing() ){

        read_vsense();
        motion_plan = G_EDM_SENSORS::get_motion_plan_probing( adc_isr_reading[0], adc_isr_reading[1] );

    } else {

        /**
          * Motion plan for the main process
          **/
        //read_vsense();
        peek_motion_plan = G_EDM_SENSORS::get_motion_plan( adc_isr_reading[0], adc_isr_reading[1], sys.gedm_retraction_motion, true );

        if( sys.gedm_retraction_motion ){
            samples = 1;
        } else {
            if( peek_motion_plan == 1 && !sys.gedm_recover_motion ) {
                samples = 20;
            } else {
                samples = 5;
            }
            if( peek_motion_plan < 4 ){
                wait_for_high_pwm = true;
            }
        }
        for( int i = 0; i < samples; ++i ){
            read_vsense( wait_for_high_pwm );
            int tmp = G_EDM_SENSORS::get_motion_plan( adc_isr_reading[0], adc_isr_reading[1], sys.gedm_retraction_motion, true );
            if( tmp == 5 && ++short_counter>2 ){
                //break;
            }
        }
        motion_plan = G_EDM_SENSORS::get_motion_plan( adc_isr_reading[0], adc_isr_reading[1], sys.gedm_retraction_motion );

    }

    plan                 = motion_plan;
    motion_plan_previous = plan;
    block_core_0_access  = false;
    return plan;
}
void IRAM_ATTR read_vsense( bool wait_for_high_pwm ){
    if( ENABLE_PWM_EVENTS && wait_for_high_pwm ){
        // wait until PWM is in ON cycle before reading the ADC
        // not sure if it is useful; needs testing!
        while( !pwm_pulse_high ){
            if( sys.abort || sys_rt_exec_state.bit.motionCancel || pwm_pulse_high ){ break; }
        }
    }

    vsense_is_reading  = 1;
    uint32_t sample    = G_EDM_SENSORS::adc1_get_fast(ADC1_CHANNEL_6);
    adc_isr_reading[0] = sample;
    adc_isr_reading[1] = int( ( sample + adc_isr_reading[1] ) / 2 );
    adc_isr_reading[2] = esp_timer_get_time();
    vsense_is_reading  = 0;
}

int G_EDM_SENSORS::get_vsense_raw(){
    block_core_0_access = true;
    while( vsense_is_reading ){ if( sys.abort || sys_rt_exec_state.bit.motionCancel ){ break; } }
    read_vsense();
    int sample = adc_isr_reading[0]; // realtime sample from last timer event
    block_core_0_access = false;
    return sample;
}