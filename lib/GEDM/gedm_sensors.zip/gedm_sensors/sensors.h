#pragma once
/*
#  ██████        ███████ ██████  ███    ███  
# ██             ██      ██   ██ ████  ████  
# ██   ███ █████ █████   ██   ██ ██ ████ ██ 
# ██    ██       ██      ██   ██ ██  ██  ██ 
#  ██████        ███████ ██████  ██      ██ 
#
# This is a beta version for testing purposes.
# Only for personal use. Commercial use or redistribution without permission is prohibited. 
# Copyright (c) Roland Lautensack        
*/ 
#include "config/definitions.h"
#include <driver/adc.h>
#include <esp_attr.h>
#include <esp32-hal.h>
#include <soc/sens_reg.h>
#include <soc/sens_struct.h>
#include <freertos/task.h>
//#include "soc/timer_group_struct.h"
//#include "soc/timer_group_reg.h"
#include "esp_intr_alloc.h"
#include "esp_attr.h"
#include "driver/timer.h"
#include "esp_adc_cal.h"
//#include <stdio.h>
//#include <stdlib.h>

//static const int    num_vsense_tasks           = 10;
static const int    vsense_sampler_buffer_size = 30;


//extern TaskHandle_t vsense_tasks[num_vsense_tasks];
extern hw_timer_t * vsense_adc_sampler_timer; 

extern DMA_ATTR volatile int      vsense_is_reading;
extern DMA_ATTR volatile int      last_adc_in_use;
extern DMA_ATTR volatile int      vsense_multisample_counts;
extern DMA_ATTR volatile uint32_t vsense_multisample_buffer[vsense_sampler_buffer_size];
extern DMA_ATTR volatile bool     block_core_0_access;
extern DMA_ATTR volatile int      reference_adc_value;
extern DMA_ATTR volatile float    reference_voltage;
extern DMA_ATTR volatile uint32_t feedback_voltage;
extern DMA_ATTR volatile float    source_voltage;
extern DMA_ATTR volatile int      vsense_update_counter;
extern DMA_ATTR volatile int      motion_plan;
extern DMA_ATTR volatile int      motion_plan_previous;
extern DMA_ATTR volatile int      counter[7];
extern DMA_ATTR volatile int      on_off_switch_event_detected;
extern DMA_ATTR volatile int      adc_isr_reading[3];
extern DMA_ATTR volatile int      adc_isr_reading_shunt[3];
extern DMA_ATTR volatile int      adc_setpoints[4];

void IRAM_ATTR default_sensor_task( void * parameter );
int  IRAM_ATTR vsense_read( void );
int  IRAM_ATTR push_sample_to_buffer( uint32_t sample );
void IRAM_ATTR switch_on_interrupt( void );
void IRAM_ATTR vsense_update_task( void * parameter );
void IRAM_ATTR read_shunt( void );
void IRAM_ATTR read_vsense( bool wait_for_high_pwm = false );


class G_EDM_SENSORS {
private:
    bool has_init;

public:
    G_EDM_SENSORS();
    int probe_positive_count;
    void init_adc( void );

    /*void vsense_tasks_pause( int number_of_tasks );
    void vsense_tasks_resume_all( void );
    void vsense_tasks_init( void );*/
    static bool IRAM_ATTR vsense_is_outdated( void );

    static uint32_t IRAM_ATTR adc_to_voltage( int adc_value );
    static uint32_t IRAM_ATTR adc1_get_fast(int channel);
    static int      IRAM_ATTR get_motion_plan( int adc_value_realtime, int adc_value_multisampled, bool retract_motion, bool peek = false );
    static int      IRAM_ATTR get_motion_plan_probing( int adc_value_realtime, int adc_value_multisampled );
    static int      IRAM_ATTR get_raw_plan( int adc_value );
    static void     IRAM_ATTR reset_buffer( int exclude = 0 );
    static float    IRAM_ATTR get_drop_in_percent_realtime( int raw );
    static float    IRAM_ATTR get_drop_in_percent( bool _update );
    static void     IRAM_ATTR update_feedback_data( void );
    static float    IRAM_ATTR calulate_source_voltage( void );
    static int      IRAM_ATTR get_calculated_motion_plan( void );
    static bool     IRAM_ATTR is_probing( void );
    static bool     IRAM_ATTR edm_start_stop( void );
    static int      IRAM_ATTR get_vsense_raw( void );
    static void     IRAM_ATTR generate_setpoint_min_max_adc( int adc_reading_reference = 0 );
    static int      IRAM_ATTR get_number_of_samples( void );
    static int      IRAM_ATTR collect_vsense( int counts );


    void run_sensor_service( void );
    uint32_t get_feedback_voltage( int adc_value = 0 );
    bool limit_is_touched( void );
    bool continue_edm_process( void );
    void generate_reference_voltage( void );
    bool start_edm_process( void );
    void collect_probe_samples( void );


};
